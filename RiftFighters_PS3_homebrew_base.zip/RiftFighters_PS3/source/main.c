#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/process.h>
#include <sysutil/sysutil.h>
#include <io/pad.h>
#include <tiny3d.h>
#include <libfont.h>

SYS_PROCESS_PARAM(1001, 0x100000);

static volatile int running = 1;
static void exit_cb(uint64_t status, uint64_t param, void *userdata) {
    (void)status; (void)param; (void)userdata;
    running = 0;
}
static void register_exit(void) {
    atexit((void (*)(void))exit_cb);
    sysUtilRegisterCallback(SYSUTIL_EVENT_SLOT0, exit_cb, NULL);
}

static int clampi(int v, int lo, int hi) {
    return v < lo ? lo : (v > hi ? hi : v);
}
static void bar(float x, float y, float w, float h, int value, u32 color) {
    tiny3d_SetPolygon(TINY3D_POLYGON_TRIANGLES);
    tiny3d_VertexPos(x, y, 0.0f);
    tiny3d_VertexColor(0xFF202028);
    tiny3d_VertexPos(x+w, y, 0.0f);
    tiny3d_VertexColor(0xFF202028);
    tiny3d_VertexPos(x+w, y+h, 0.0f);
    tiny3d_VertexColor(0xFF202028);
    tiny3d_VertexPos(x, y+h, 0.0f);
    tiny3d_VertexColor(0xFF202028);
    tiny3d_End();
    float fw = (w-4.0f) * ((float)value/1000.0f);
    tiny3d_SetPolygon(TINY3D_POLYGON_TRIANGLES);
    tiny3d_VertexPos(x+2, y+2, 0.0f); tiny3d_VertexColor(color);
    tiny3d_VertexPos(x+2+fw, y+2, 0.0f); tiny3d_VertexColor(color);
    tiny3d_VertexPos(x+2+fw, y+h-2, 0.0f); tiny3d_VertexColor(color);
    tiny3d_VertexPos(x+2, y+h-2, 0.0f); tiny3d_VertexColor(color);
    tiny3d_End();
}
static void box(float x,float y,float w,float h,u32 color) {
    tiny3d_SetPolygon(TINY3D_POLYGON_TRIANGLES);
    tiny3d_VertexPos(x,y,0); tiny3d_VertexColor(color);
    tiny3d_VertexPos(x+w,y,0); tiny3d_VertexColor(color);
    tiny3d_VertexPos(x+w,y+h,0); tiny3d_VertexColor(color);
    tiny3d_VertexPos(x,y+h,0); tiny3d_VertexColor(color);
    tiny3d_End();
}
int main(int argc, char **argv) {
    (void)argc; (void)argv;
    register_exit();
    padInit(7);
    tiny3d_Init(1024*1024);
    tiny3d_UserViewport(0, 0, 848, 512, 0, 1);
    font_init();

    int hp1=1000, hp2=1000, timer=99*60, cooldown1=0, cooldown2=0;
    int x1=245, x2=600, round=1, mode=0;
    while(running) {
        padData p1, p2;
        memset(&p1,0,sizeof(p1)); memset(&p2,0,sizeof(p2));
        padGetData(0,&p1); padGetData(1,&p2);
        if(mode==0 && (p1.BTN_START || p1.BTN_CROSS)) mode=1;
        if(mode==1) {
            if(p1.BTN_LEFT) x1=clampi(x1-3,45,780);
            if(p1.BTN_RIGHT) x1=clampi(x1+3,45,780);
            if(p2.BTN_LEFT) x2=clampi(x2-3,45,780);
            if(p2.BTN_RIGHT) x2=clampi(x2+3,45,780);
            if(cooldown1>0) cooldown1--;
            if(cooldown2>0) cooldown2--;
            if(p1.BTN_CROSS && cooldown1==0) {
                cooldown1=24;
                if(abs(x1-x2)<125) hp2=clampi(hp2-55,0,1000);
            }
            if(p1.BTN_SQUARE && cooldown1==0) {
                cooldown1=42;
                if(abs(x1-x2)<140) hp2=clampi(hp2-105,0,1000);
            }
            if(p2.BTN_CROSS && cooldown2==0) {
                cooldown2=24;
                if(abs(x1-x2)<125) hp1=clampi(hp1-55,0,1000);
            }
            if(p2.BTN_SQUARE && cooldown2==0) {
                cooldown2=42;
                if(abs(x1-x2)<140) hp1=clampi(hp1-105,0,1000);
            }
            if(timer>0) timer--;
            if(hp1==0 || hp2==0 || timer==0) mode=2;
        }
        tiny3d_Clear(0xFF100E16, TINY3D_CLEAR_ALL);
        tiny3d_Project2D();
        box(0,0,848,512,0xFF171321);
        box(0,360,848,152,0xFF241A20);
        box(0,354,848,6,0xFF9A6338);
        /* Silhuetas provisórias dos lutadores: substituíveis por modelos 3D. */
        box(x1,245,42,105,0xFFD39A38);
        box(x1+5,220,32,30,0xFF5B281D);
        box(x2,245,42,105,0xFF55B9DE);
        box(x2+5,220,32,30,0xFF173B60);
        bar(28,24,350,22,hp1,0xFF73C95A);
        bar(470,24,350,22,hp2,0xFF73C95A);
        fontDraw2D(30,60,1.0f,0xFFFFFFFF,"RIFT FIGHTERS");
        fontDraw2D(720,60,1.0f,0xFFFFFFFF,"PS3 HOMEbrew");
        char buf[64];
        snprintf(buf,sizeof(buf),"TEMPO: %02d",timer/60);
        fontDraw2D(390,82,1.0f,0xFFFFFFFF,buf);
        if(mode==0) {
            fontDraw2D(285,220,1.5f,0xFFE8BD72,"RIFT FIGHTERS");
            fontDraw2D(260,270,1.0f,0xFFFFFFFF,"APERTE X OU START PARA JOGAR");
        } else if(mode==2) {
            fontDraw2D(310,210,1.4f,0xFFFFD28A,"FIM DO ROUND");
            fontDraw2D(245,260,1.0f,0xFFFFFFFF,"START PARA SAIR PELO MENU XMB");
        } else {
            fontDraw2D(40,470,0.8f,0xFFFFFFFF,"P1: DIRECIONAL MOVE | X: SOCO | QUADRADO: FORTE");
            fontDraw2D(475,490,0.8f,0xFFFFFFFF,"P2: CONTROLE 2");
        }
        tiny3d_Flip();
        usleep(16666);
        if(mode==2 && p1.BTN_START) { running=0; }
    }
    fontEnd();
    padEnd();
    return 0;
}
